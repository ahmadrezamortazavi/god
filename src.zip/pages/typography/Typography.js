import React from "react";
import { Grid } from "@material-ui/core";

// styles
import useStyles from "./styles";

// components
import PageTitle from "../../components/PageTitle";
import Widget from "../../components/Widget";
import { Typography } from "../../components/Wrappers";

export default function TypographyPage() {
  var classes = useStyles();

  return (
    <>
      <PageTitle title="تایپوگرافی" />
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Widget title="عنوان ها" disableWidgetMenu>
            <div className={classes.dashedBorder}>
              <Typography variant="h1" className={classes.text}>
              عنوان 1
              </Typography>
              <Typography variant="h2" className={classes.text}>
              عنوان 2
              </Typography>
              <Typography variant="h3" className={classes.text}>
              عنوان 3
              </Typography>
              <Typography variant="h4" className={classes.text}>
              عنوان 4
              </Typography>
              <Typography variant="h5" className={classes.text}>
              عنوان 5
              </Typography>
              <Typography variant="h6">عنوان 6</Typography>
            </div>
          </Widget>
        </Grid>
        <Grid item xs={12} md={6}>
          <Widget title="رنگ های تایپوگرافی" disableWidgetMenu>
            <div className={classes.dashedBorder}>
              <Typography variant="h1" color="primary" className={classes.text}>
              عنوان 1
              </Typography>
              <Typography variant="h2" color="success" className={classes.text}>
              عنوان 2
              </Typography>
              <Typography
                variant="h3"
                color="secondary"
                className={classes.text}
              >
               عنوان 3
              </Typography>
              <Typography variant="h4" color="warning" className={classes.text}>
              عنوان 4
              </Typography>
              <Typography
                variant="h5"
                color="primary"
                colorBrightness="light"
                className={classes.text}
              >
               عنوان 5
              </Typography>
              <Typography variant="h6" color="info">
              عنوان 6
              </Typography>
            </div>
          </Widget>
        </Grid>
        <Grid item xs={12} md={6}>
          <Widget title="تنظیمات اساسی متن" disableWidgetMenu>
            <div className={classes.dashedBorder}>
              <Typography className={classes.text}>متن اصلی</Typography>
              <Typography className={classes.text} weight="light">
              متن سبک اصلی
              </Typography>
              <Typography className={classes.text} weight="medium">
              متن متوسط ​​اولیه
              </Typography>
              <Typography className={classes.text} weight="bold">
              متن اصلی پررنگ
              </Typography>
              <Typography className={classes.text}>
              متن بزرگ بزرگ
              </Typography>
              <Typography className={classes.text}>
              متن کوچک کوچک
              </Typography>
              <Typography className={classes.text}>
              متن اصلی بزرگ
              </Typography>
              <Typography>
                <i>متن خط مقدماتی</i>
              </Typography>
            </div>
          </Widget>
        </Grid>
        <Grid item xs={12} md={6}>
          <Widget title="اندازه متن" disableWidgetMenu>
            <div className={classes.dashedBorder}>
              <Typography className={classes.text} size="sm">
              عنوان تایپوگرافی اندازه قلم SM
              </Typography>
              <Typography className={classes.text}>
              عنوان تایپوگرافی اندازه قلم منظم
              </Typography>
              <Typography className={classes.text} size="md">
              عنوان تایپوگرافی اندازه قلم MD
              </Typography>
              <Typography className={classes.text} size="xl">
              عنوان تایپوگرافی XL اندازه قلم
              </Typography>
              <Typography className={classes.text} size="xxl">
              عنوان تایپوگرافی XXL اندازه قلم
              </Typography>
            </div>
          </Widget>
        </Grid>
      </Grid>
    </>
  );
}
